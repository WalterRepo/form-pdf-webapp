<?php

if (!defined('ABSPATH')) {
    exit;
}

final class ACL_Forms_Mailer
{
    private static function send(string $to, string $subject, string $body, array $attachments): bool
    {
        $headers = ['Content-Type: text/html; charset=UTF-8'];
        return wp_mail($to, $subject, $body, $headers, $attachments);
    }

    public static function registration(array $data, string $pdf_path, string $audit_path, array $audit): array
    {
        $name = esc_html(trim($data['nome'] . ' ' . $data['cognome']));
        $document_id = esc_html($audit['documentId']);
        $hash = esc_html($audit['documentHash']);
        $user_body = "<p>Ciao {$name},</p><p>abbiamo ricevuto la tua domanda di iscrizione. In allegato trovi il modulo PDF compilato.</p><p><strong>ID documento:</strong> {$document_id}<br><strong>Hash SHA-256:</strong> <code>{$hash}</code></p><p>La Bora ASD</p>";
        $admin_body = "<p>Nuova iscrizione ricevuta da <strong>{$name}</strong>.</p><p><strong>Email:</strong> " . esc_html($data['email']) . "<br><strong>ID documento:</strong> {$document_id}<br><strong>Hash documento:</strong> <code>{$hash}</code></p>";
        return [
            'user' => self::send($data['email'], 'Conferma iscrizione - La Bora', $user_body, [$pdf_path]),
            'admin' => self::send(ACL_Forms_Config::registration_admin_email(), 'Nuova iscrizione - ' . $name, $admin_body, [$pdf_path, $audit_path]),
        ];
    }

    public static function receipt(array $data, string $pdf_path, string $hash): array
    {
        $number = (int) $data['numeroRicevuta'];
        $payer = esc_html($data['ricevutoDa']);
        $body = "<p>In allegato trovi la ricevuta n. <strong>{$number}</strong> intestata a {$payer}.</p><p><strong>Hash SHA-256:</strong> <code>" . esc_html($hash) . "</code></p><p>La Bora ASD</p>";
        $admin_body = "<p>È stata emessa la ricevuta n. <strong>{$number}</strong> per {$payer}.</p><p><strong>Importo:</strong> € " . esc_html(number_format((float) $data['denaroRicevuto'], 2, ',', '.')) . "</p>";
        return [
            'user' => self::send($data['emailPagante'], "Ricevuta n. {$number} - La Bora", $body, [$pdf_path]),
            'admin' => self::send(ACL_Forms_Config::receipts_admin_email(), "Ricevuta emessa n. {$number}", $admin_body, [$pdf_path]),
        ];
    }
}
