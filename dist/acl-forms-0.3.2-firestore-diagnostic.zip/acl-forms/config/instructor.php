<?php

if (!defined('ABSPATH')) {
    exit;
}

// ID del documento dell'istruttore nella collection Firestore "handlers".
// Compilare solo dopo aver scelto l'istruttore predefinito dei nuovi binomi.
return 'TMG0DzdODcYFkzyMgEqc';
